#!/usr/bin/env python3
"""Check results/*.json against every value printed in the article.

No dataset, no GPU, about a second:

    python scripts/verify_results.py

Exit status is 0 if every assertion passes, 1 otherwise.
"""
from __future__ import annotations

import json
import math
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
RESULTS = os.path.join(os.path.dirname(HERE), "results")

ok = 0
bad: list[str] = []


def check(label: str, measured: float, printed: float, tol: float = 0.005) -> None:
    """Compare a measured value with the figure printed in the article."""
    global ok
    if abs(measured - printed) <= tol:
        print(f"  PASS  {label:<52} {measured:>9.4f}")
        ok += 1
    else:
        print(f"  FAIL  {label:<52} {measured:>9.4f}  article says {printed}")
        bad.append(label)


def load(name: str):
    path = os.path.join(RESULTS, name)
    if not os.path.exists(path):
        print(f"  MISSING  {name}")
        bad.append(name)
        return None
    with open(path) as fh:
        return json.load(fh)


# ------------------------------------------------- Table 4: WUSTL parametric
print("\nTable 4 -- WUSTL-IIoT-2021, configurations evaluated")
t3 = load("table3_fast_T15_f30_noleak.json")
if t3:
    for key, acc, f1w, bal, mac, mcc in [
        ("H",  98.33, 0.984, 98.50, 0.944, 0.892),
        ("E4", 98.45, 0.985, 98.66, 0.947, 0.899),
        ("N",  99.92, 0.999, 99.93, 0.997, 0.994),
    ]:
        v = t3[key]
        check(f"{key}: accuracy (%)",         v["acc"] * 100,      acc)
        check(f"{key}: weighted F1",          v["f1_weighted"],    f1w)
        check(f"{key}: balanced accuracy (%)", v["bal_acc"] * 100, bal)
        check(f"{key}: macro F1",             v["f1_macro"],       mac)
        check(f"{key}: MCC",                  v["mcc"],            mcc)

    # Section 6.1 per-class figures
    print("\nSection 6.1 -- per-class figures at eps = 0.5")
    (tn, fp), (fn, tp) = t3["H"]["confusion_matrix"]
    c0, c1 = t3["H"]["per_class"]
    check("benign precision",      c0["precision"], 0.9990, 0.0001)
    check("benign recall",         c0["recall"],    0.9831, 0.0001)
    check("attack precision",      c1["precision"], 0.8208, 0.0001)
    check("attack recall",         c1["recall"],    0.9869, 0.0001)
    check("attacks missed",        fn,              201,    0)
    check("false alarms",          fp,              3293,   0)
    check("false positive rate (%)", 100 * fp / (tn + fp), 1.69, 0.01)

    # Table 5 horizon
    print("\nTable 5 -- training horizon")
    vh = {z["round"]: z for z in t3["H"]["val_history"]}
    for T, val in [(5, 97.75), (10, 98.29), (15, 98.40)]:
        check(f"T = {T}: validation accuracy (%)", vh[T]["val_acc"] * 100, val)
        eps_dp = T * 0.5 + math.log(1 / 1e-5) / (5.0 - 1)
        check(f"T = {T}: eps^DP", eps_dp, {5: 5.38, 10: 7.88, 15: 10.38}[T], 0.01)

# ------------------------------------------------- Table 9: ablation
print("\nTable 9 -- ablation, WUSTL-IIoT-2021 column")
t8 = load("table8_fast_T15_f30_noleak.json")
if t8:
    R = {v["config"]: v for v in t8.values()}
    for key, acc, f1 in [("A", 98.38, 0.984), ("B", 98.39, 0.985),
                         ("C", 97.99, 0.981), ("D", 98.03, 0.981)]:
        check(f"{R[key]['label']}: accuracy (%)", R[key]["acc"] * 100, acc)
        check(f"{R[key]['label']}: F1",           R[key]["f1"],        f1)

    print("\nSection 6.3 -- both halves of the 2x2 design")
    d_ft = (R["A"]["acc"] - R["C"]["acc"]) * 100
    d_fa = (R["B"]["acc"] - R["D"]["acc"]) * 100
    check("LRDP over std DP, with FedTrust (points)", d_ft, 0.40, 0.02)
    check("LRDP over std DP, with FedAvg (points)",   d_fa, 0.36, 0.02)
    if d_ft > 0 and d_fa > 0:
        print("  PASS  LRDP beats standard DP in both halves")
        ok += 1
    else:
        print("  FAIL  LRDP does not beat standard DP in both halves")
        bad.append("LRDP replication")

# ------------------------------------------------- Table 6: ToN-IoT
print("\nTable 6 -- ToN-IoT network, federated sweep")
t5 = load("table5_federated_T30_C.json")
if t5:
    rows = [("e0.5", 0.5, 95.55, 0.956, 96.26, 97.56, 0.884),
            ("e1.0", 1.0, 95.64, 0.957, 96.36, 97.70, 0.886),
            ("e2.875", 2.875, 98.06, 0.981, 98.19, 98.43, 0.946),
            ("e5.25", 5.25, 98.21, 0.982, 98.22, 98.25, 0.950),
            ("e7.625", 7.625, 98.22, 0.982, 98.20, 98.17, 0.951),
            ("e10.0", 10.0, 98.34, 0.983, 98.25, 98.08, 0.954)]
    for key, eps, acc, f1w, bal, spec, mcc in rows:
        v = t5[key]
        check(f"eps = {eps}: accuracy (%)",  v["acc"] * 100,         acc)
        check(f"eps = {eps}: weighted F1",   v["f1_weighted"],       f1w)
        check(f"eps = {eps}: balanced (%)",  v["bal_acc"] * 100,     bal)
        check(f"eps = {eps}: specificity (%)", v["specificity"]*100, spec)
        check(f"eps = {eps}: MCC",           v["mcc"],               mcc)
        sigma = math.sqrt(10.0 / (2 * eps))          # Eq. (4), C = 1
        check(f"eps = {eps}: sigma from Eq. (4)", v["sigma"], round(sigma, 4), 1e-4)

    accs = [t5[k]["acc"] for k, *_ in rows]
    if accs == sorted(accs):
        print("  PASS  accuracy is monotonic in epsilon")
        ok += 1
    else:
        print("  FAIL  accuracy is not monotonic in epsilon")
        bad.append("monotonicity")

    print("\nAbstract -- ToN-IoT range")
    check("lowest accuracy (%)",  min(accs) * 100, 95.55)
    check("highest accuracy (%)", max(accs) * 100, 98.34)

    print("\nFigures 3 and 4 -- eps = 1.0")
    (tn, fp), (fn, tp) = t5["e1.0"]["confusion_matrix"]
    check("attacks correctly detected", tp, 26913, 0)
    check("normal correctly classified", tn, 8203, 0)
    check("false negatives", fn, 1408, 0)
    check("false positives", fp, 193, 0)
    check("ROC-AUC", t5["e1.0"]["roc_auc"], 0.9910, 0.0001)
    check("average precision", t5["e1.0"]["avg_precision"], 0.9967, 0.0001)

# ------------------------------------------------- summary
print("\n" + "=" * 72)
if bad:
    print(f"{ok} checks passed, {len(bad)} FAILED:")
    for b in bad:
        print(f"   - {b}")
    sys.exit(1)
print(f"All {ok} checks passed: results/ matches the article.")
sys.exit(0)
