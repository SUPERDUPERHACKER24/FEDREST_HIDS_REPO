"""The noise-scale formula actually used in the notebooks.

`privacy.py` implements Eq. (4) of the article. This module implements what the
notebooks compute, so that a reader can reproduce the reported runs *and* see
precisely how the two differ. Both are provided deliberately; neither is
hidden.

Article, Eq. (4) -- a closed-form inversion of the Gaussian mechanism's Renyi
divergence, exact for a single release:

    sigma = C * sqrt(alpha / (2 * eps))

Notebooks -- an expression combining an (eps, delta) variance term with a
composition factor and a tunable multiplier:

    base_variance = 2 * alpha * ln(1/delta) / eps^2
    composition   = sqrt(T * ln(1/delta))          T = rounds * epochs * 10
    sigma         = sqrt(base_variance * composition) * noise_scale_factor * C

The second is not a Renyi calibration. It carries a `noise_scale_factor` with
no counterpart in the article, and it folds a composition term into the
per-round scale, whereas Renyi composition is applied once afterwards
(Eq. 5). At the configuration declared in the WUSTL notebook the two differ by
roughly an order of magnitude.

Where the placement of the noise is concerned the two agree: both clip the
per-batch gradient to C and perturb it, as Eq. (2) specifies.
"""
from __future__ import annotations

import math


def legacy_noise_scale(epsilon: float, delta: float, alpha: float,
                       clip_norm: float, n_iterations: int,
                       noise_scale_factor: float = 0.5) -> float:
    """Reproduce the notebooks' noise scale exactly.

    Provided for reproducibility of the reported runs. It is NOT Eq. (4);
    use :func:`fedrest.privacy.noise_scale` for the article's calibration.
    """
    base_variance = 2.0 * alpha * math.log(1.0 / delta) / (epsilon ** 2)
    composition = math.sqrt(n_iterations * math.log(1.0 / delta))
    return math.sqrt(base_variance * composition) * noise_scale_factor * clip_norm


def compare(epsilon: float, delta: float, alpha: float, clip_norm: float,
            n_iterations: int, noise_scale_factor: float = 0.5) -> str:
    """Side-by-side report of the two calibrations at one configuration."""
    from .privacy import noise_scale
    paper = noise_scale(clip_norm, alpha, epsilon)
    legacy = legacy_noise_scale(epsilon, delta, alpha, clip_norm,
                                n_iterations, noise_scale_factor)
    return (f"eps={epsilon}  alpha={alpha}  delta={delta}  C={clip_norm}  "
            f"T={n_iterations}  factor={noise_scale_factor}\n"
            f"  Eq. (4)   sigma = {paper:8.4f}\n"
            f"  notebooks sigma = {legacy:8.4f}\n"
            f"  ratio           = {legacy / paper:8.1f}x")


if __name__ == "__main__":
    print("WUSTL notebook, as declared in its CONFIG block")
    print(compare(epsilon=5.0, delta=1e-5, alpha=3.0, clip_norm=1.0,
                  n_iterations=50 * 5 * 10, noise_scale_factor=0.5))
    print()
    print("Article headline for the same dataset")
    from privacy import noise_scale          # type: ignore
    print(f"  eps=0.5  alpha=5.0  C=1.0  ->  sigma = {noise_scale(1.0, 5.0, 0.5):.4f}")
