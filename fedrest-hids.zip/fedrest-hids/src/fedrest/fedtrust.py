"""FedTrust: trust-aware aggregation.

Section 3.2.3 of the article.  Each client k receives a scalar trust score

    s_k = zeta_1 * T_temp + zeta_2 * T_beh + zeta_3 * T_res,     sum(zeta) = 1

and the global model is the softmax-weighted mean of the client updates:

    W_G = sum_k p_k W_k,     p_k = softmax(s_k)

Components
----------
T_temp  exp(-lambda * (t - t_k)) * Perf(k, t),
        Perf = beta_1 * F1 + beta_2 * AUC        (Eq. 6)
T_beh   max(0, 1 - ||W_k - W_mean||_2 / tau)
T_res   (R_k / R_max) * ProcCap(k)

Defaults follow Section 6.1: zeta = 1/3 each, beta_1 = 0.6, beta_2 = 0.4,
lambda = 0.05 per round.  tau is calibrated as the 95th percentile of the
pairwise distances observed in a two-round warm-up; the article reports 0.42,
0.37 and 0.51 for WUSTL-IIoT-2021, ToN-IoT and SCVIC-APT-2021.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Dict, Sequence

try:
    import torch
except ImportError:                     # pragma: no cover
    torch = None


def softmax(scores: Sequence[float]) -> list[float]:
    """Numerically stable softmax."""
    m = max(scores)
    e = [math.exp(s - m) for s in scores]
    z = sum(e)
    return [x / z for x in e]


@dataclass
class TrustConfig:
    zeta_temporal: float = 1.0 / 3.0
    zeta_behavioral: float = 1.0 / 3.0
    zeta_resource: float = 1.0 / 3.0
    beta_f1: float = 0.6
    beta_auc: float = 0.4
    decay: float = 0.05        # lambda
    tau: float = 0.42          # per-dataset; see docstring

    def __post_init__(self) -> None:
        z = self.zeta_temporal + self.zeta_behavioral + self.zeta_resource
        if abs(z - 1.0) > 1e-6:
            raise ValueError(f"zeta weights must sum to 1, got {z}")
        if abs(self.beta_f1 + self.beta_auc - 1.0) > 1e-6:
            raise ValueError("beta weights must sum to 1")


def temporal_trust(round_now: int, round_last: int, f1: float, auc: float,
                   cfg: TrustConfig) -> float:
    perf = cfg.beta_f1 * f1 + cfg.beta_auc * auc          # Eq. (6)
    return math.exp(-cfg.decay * (round_now - round_last)) * perf


def behavioral_trust(deviation: float, cfg: TrustConfig) -> float:
    """deviation = ||W_k - W_mean||_2.  Clipped at 0, so an outlier client
    contributes no negative weight but is not excluded outright."""
    return max(0.0, 1.0 - deviation / cfg.tau)


def resource_trust(capacity: float, capacity_max: float,
                   proc_capability: float) -> float:
    if capacity_max <= 0:
        raise ValueError("capacity_max must be positive")
    return (capacity / capacity_max) * proc_capability


@dataclass
class FedTrust:
    cfg: TrustConfig = field(default_factory=TrustConfig)

    def score(self, *, round_now: int, round_last: int, f1: float, auc: float,
              deviation: float, capacity: float, capacity_max: float,
              proc_capability: float) -> float:
        c = self.cfg
        return (c.zeta_temporal
                * temporal_trust(round_now, round_last, f1, auc, c)
                + c.zeta_behavioral * behavioral_trust(deviation, c)
                + c.zeta_resource
                * resource_trust(capacity, capacity_max, proc_capability))

    @staticmethod
    def weights(scores: Sequence[float]) -> list[float]:
        return softmax(scores)

    @staticmethod
    def aggregate(state_dicts: Sequence[Dict], scores: Sequence[float]):
        """Softmax-weighted mean of client state dicts."""
        if torch is None:
            raise RuntimeError("PyTorch required for aggregation")
        if len(state_dicts) != len(scores):
            raise ValueError("one score per client is required")
        p = softmax(scores)
        out = {}
        for key in state_dicts[0]:
            acc = torch.zeros_like(state_dicts[0][key], dtype=torch.float32)
            for w, sd in zip(p, state_dicts):
                acc += w * sd[key].float()
            out[key] = acc.to(state_dicts[0][key].dtype)
        return out

    @staticmethod
    def fedavg(state_dicts: Sequence[Dict]):
        """Uniform averaging -- the baseline FedTrust is compared against."""
        return FedTrust.aggregate(state_dicts, [0.0] * len(state_dicts))


# ---------------------------------------------------------------------------
# Privacy note
# ---------------------------------------------------------------------------
# Section 3.2.3 argues that the trust computation incurs no additional privacy
# cost (delta_eps_trust = 0) by the post-processing property.  That argument
# holds for T_beh and T_res, whose inputs are respectively an already-noised
# parameter vector and non-sensitive device metadata.  It is weaker for T_temp,
# because F1 and AUC are computed on a held-out slice of the client's RAW data:
# post-processing covers functions of a mechanism's OUTPUT, and raw data is an
# input here.  See docs/KNOWN_ISSUES.md.
