"""Model definitions.

Three architectures are used in the article:

  CNNHIDS         the 3-layer CNN-HIDS trained on resource-rich devices
  ClientSideModel the single feature-extraction layer executed on a
                  resource-constrained device (everything before the cut)
  EdgeSideModel   the remaining layers, executed on the edge server

The cut is placed after the first layer (Section 3.2.4), so an RC device holds
only ``ClientSideModel`` and never stores or updates the deeper parameters.

``ClientSideModel.activation_dim`` is the quantity ``A`` in the communication
model of Section 6.5 -- the number of values transmitted per sample.
"""
from __future__ import annotations

try:
    import torch
    import torch.nn as nn
    _HAS_TORCH = True
except ImportError:                     # pragma: no cover
    # Allow the module to be imported without PyTorch so that the pure-maths
    # parts of the package (privacy, comms) remain usable.  Instantiating any
    # model without torch raises a clear error.
    torch = None
    _HAS_TORCH = False

    class _StubModule:
        def __init__(self, *a, **k):
            raise RuntimeError("PyTorch is required to build models")

    class _Stub:
        Module = _StubModule

        def __getattr__(self, name):
            raise RuntimeError("PyTorch is required to build models")

    nn = _Stub()


class CNNHIDS(nn.Module):
    """3-layer CNN-HIDS for resource-rich devices.

    Section 6.1 evaluates this against a 5-layer variant; three layers gave the
    better privacy-utility balance, the deeper model leaning more heavily on the
    majority class under DP noise (Table 3).
    """

    def __init__(self, n_features: int, n_classes: int = 2,
                 channels: tuple[int, int, int] = (32, 64, 64),
                 dropout: float = 0.3):
        super().__init__()
        c1, c2, c3 = channels
        self.features = nn.Sequential(
            nn.Conv1d(1, c1, kernel_size=3, padding=1), nn.BatchNorm1d(c1),
            nn.ReLU(), nn.Dropout(dropout),
            nn.Conv1d(c1, c2, kernel_size=3, padding=1), nn.BatchNorm1d(c2),
            nn.ReLU(), nn.Dropout(dropout),
            nn.Conv1d(c2, c3, kernel_size=3, padding=1), nn.BatchNorm1d(c3),
            nn.ReLU(), nn.AdaptiveAvgPool1d(1),
        )
        self.classifier = nn.Linear(c3, n_classes)

    def forward(self, x):
        if x.dim() == 2:
            x = x.unsqueeze(1)                     # (B, 1, F)
        h = self.features(x).squeeze(-1)
        return self.classifier(h)

    @property
    def n_parameters(self) -> int:
        """P in the communication model of Section 6.5."""
        return sum(p.numel() for p in self.parameters() if p.requires_grad)


class ClientSideModel(nn.Module):
    """Layers held by a resource-constrained device -- everything before the cut."""

    def __init__(self, n_features: int, out_channels: int = 32,
                 pool: bool = True):
        super().__init__()
        self.n_features = n_features
        self.out_channels = out_channels
        self.pool = pool
        self.layer = nn.Sequential(
            nn.Conv1d(1, out_channels, kernel_size=3, padding=1),
            nn.BatchNorm1d(out_channels),
            nn.ReLU(),
        )
        self.reduce = nn.AdaptiveAvgPool1d(1) if pool else nn.Identity()

    def forward(self, x):
        if x.dim() == 2:
            x = x.unsqueeze(1)
        h = self.layer(x)
        h = self.reduce(h)
        return h.flatten(1)

    @property
    def activation_dim(self) -> int:
        """A in the communication model -- values sent per sample.

        With pooling the map collapses to ``out_channels``; without it the full
        ``out_channels * n_features`` map crosses the link, which is roughly a
        forty-fold difference in traffic on these datasets.
        """
        return self.out_channels if self.pool else self.out_channels * self.n_features


class EdgeSideModel(nn.Module):
    """Layers held by the edge server -- everything after the cut."""

    def __init__(self, in_dim: int, n_classes: int = 2, hidden: int = 64,
                 dropout: float = 0.3):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden), nn.ReLU(), nn.Dropout(dropout),
            nn.Linear(hidden, hidden), nn.ReLU(), nn.Dropout(dropout),
            nn.Linear(hidden, n_classes),
        )

    def forward(self, x):
        return self.net(x)


def build_split_pair(n_features: int, n_classes: int = 2,
                     out_channels: int = 32, pool: bool = True):
    """Construct a matched client/edge pair with a consistent cut dimension."""
    client = ClientSideModel(n_features, out_channels=out_channels, pool=pool)
    edge = EdgeSideModel(client.activation_dim, n_classes=n_classes)
    return client, edge
