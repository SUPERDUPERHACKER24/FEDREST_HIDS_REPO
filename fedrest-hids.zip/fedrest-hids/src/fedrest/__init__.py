"""FedREST-HIDS: split-federated intrusion detection for resource-heterogeneous IIoT.

Reference implementation accompanying the article. See docs/KNOWN_ISSUES.md
for documented divergences between this library and the notebooks that
produced the reported results.
"""

__version__ = "1.0.0"

from .privacy import LocalRenyiDP, noise_scale, compose, rdp_to_dp, allocate
from .fedtrust import FedTrust, TrustConfig
from .comms import CommsProfile, bytes_split_learning, bytes_federated, break_even_parameters
from .models import CNNHIDS, ClientSideModel, EdgeSideModel, build_split_pair
from .poisoning import label_flip, sign_flip, select_malicious
from .legacy import legacy_noise_scale
from .training import TrainConfig, train_client_rr, train_client_rc, federated_round

__all__ = [
    "LocalRenyiDP", "noise_scale", "compose", "rdp_to_dp", "allocate",
    "FedTrust", "TrustConfig",
    "CommsProfile", "bytes_split_learning", "bytes_federated", "break_even_parameters",
    "CNNHIDS", "ClientSideModel", "EdgeSideModel", "build_split_pair",
    "label_flip", "sign_flip", "select_malicious",
    "legacy_noise_scale",
    "TrainConfig", "train_client_rr", "train_client_rc", "federated_round",
]
