"""Training loops, faithful to Algorithms 1-4 of the article.

This module implements the mechanism as the article states it, and as the
notebooks implement it -- the two agree on structure.

    Eq. (2)  M(g) = clip(g, C) + N(0, sigma^2 I)

    applied to the PER-BATCH GRADIENT at every optimisation step. The WUSTL
    notebook's `LocalRenyiDPEngine.clip_and_add_noise` does exactly this,
    operating on `p.grad` inside the training loop, so the placement of the
    noise here matches both the article and the notebooks.

    Where the notebooks DIVERGE is the noise SCALE. They compute sigma from an
    expression that mixes an (eps, delta) variance term with a composition
    factor and a tunable multiplier, rather than from Eq. (4). See
    `fedrest.legacy` for that formula and `docs/KNOWN_ISSUES.md` section 2 for
    the size of the difference.

    This module uses Eq. (4) via `fedrest.privacy.LocalRenyiDP`. To reproduce a
    notebook run instead, pass a mechanism built with
    `fedrest.legacy.legacy_noise_scale`.

"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Dict, Iterable, Sequence

from .privacy import LocalRenyiDP
from .fedtrust import FedTrust, TrustConfig

try:
    import torch
    import torch.nn as nn
except ImportError:                     # pragma: no cover
    torch = None
    nn = object


# --------------------------------------------------------------------------
@dataclass
class TrainConfig:
    local_epochs: int = 5          # E; Table 2 gives 5 for RR, 3 for RC
    lr: float = 1e-3
    batch_size: int = 64
    clip_norm: float = 1.0         # C
    alpha: float = 5.0
    epsilon: float = 0.5           # per-round Renyi budget
    delta: float = 1e-5
    seed: int = 42


# --------------------------------------------------------------------------
# Algorithm 1 -- resource-rich client
# --------------------------------------------------------------------------
def train_client_rr(model, loader, cfg: TrainConfig,
                    loss_fn=None, device="cpu"):
    """One round of local training on a resource-rich device.

    Implements Eq. (2) per optimisation step:

        g   <- grad of loss on the batch
        g   <- g * min(1, C / ||g||_2)            # clip to sensitivity C
        g   <- g + N(0, sigma^2 I)                # sigma from Eq. (4)
        W   <- W - eta * g

    The noise is applied to the GRADIENT at every step, not to the parameter
    vector once per round. That is the correction described in the module
    docstring.

    Returns
    -------
    state_dict, mechanism
    """
    if torch is None:
        raise RuntimeError("PyTorch required")
    loss_fn = loss_fn or nn.CrossEntropyLoss()
    model = model.to(device).train()
    opt = torch.optim.Adam(model.parameters(), lr=cfg.lr)
    dp = LocalRenyiDP(clip_norm=cfg.clip_norm, alpha=cfg.alpha,
                      epsilon=cfg.epsilon, delta=cfg.delta)

    for _ in range(cfg.local_epochs):
        for xb, yb in loader:
            xb, yb = xb.to(device), yb.to(device)
            opt.zero_grad(set_to_none=True)
            loss_fn(model(xb), yb).backward()

            # --- Eq. (2): clip the gradient to l2 <= C ---------------------
            torch.nn.utils.clip_grad_norm_(model.parameters(), cfg.clip_norm)

            # --- Eq. (2): perturb with N(0, sigma^2), sigma from Eq. (4) ---
            with torch.no_grad():
                for p in model.parameters():
                    if p.grad is not None:
                        p.grad.add_(torch.normal(
                            mean=0.0, std=dp.sigma, size=p.grad.shape,
                            device=p.grad.device, dtype=p.grad.dtype))
            opt.step()

    # one round consumes one per-round budget
    dp._spent.append(dp.epsilon)
    return {k: v.detach().cpu() for k, v in model.state_dict().items()}, dp


# --------------------------------------------------------------------------
# Algorithm 2 / 4 -- resource-constrained client via split learning
# --------------------------------------------------------------------------
def train_client_rc(client_model, edge_model, loader, cfg: TrainConfig,
                    loss_fn=None, device="cpu"):
    """One round of split training for a resource-constrained device.

    The device runs the client-side layer, clips the ACTIVATIONS to l2 <= C,
    perturbs them, and transmits them. The edge server runs the remaining
    layers and returns the activation gradients. Section 3.2.4 and Algorithm 2.

    Activations are clipped and noised per batch, consistent with the
    per-release calibration of Eq. (4).
    """
    if torch is None:
        raise RuntimeError("PyTorch required")
    loss_fn = loss_fn or nn.CrossEntropyLoss()
    client_model = client_model.to(device).train()
    edge_model = edge_model.to(device).train()
    opt_c = torch.optim.Adam(client_model.parameters(), lr=cfg.lr)
    opt_e = torch.optim.Adam(edge_model.parameters(), lr=cfg.lr)
    dp = LocalRenyiDP(clip_norm=cfg.clip_norm, alpha=cfg.alpha,
                      epsilon=cfg.epsilon, delta=cfg.delta)

    for _ in range(cfg.local_epochs):
        for xb, yb in loader:
            xb, yb = xb.to(device), yb.to(device)
            opt_c.zero_grad(set_to_none=True)
            opt_e.zero_grad(set_to_none=True)

            # device side: forward to the cut layer
            act = client_model(xb)

            # clip + perturb the activations before they leave the device
            norm = act.norm(p=2, dim=1, keepdim=True)
            act = act * torch.clamp(cfg.clip_norm / (norm + 1e-12), max=1.0)
            act = act + torch.normal(mean=0.0, std=dp.sigma, size=act.shape,
                                     device=act.device, dtype=act.dtype)

            # edge side: remaining layers, loss, backward
            loss_fn(edge_model(act), yb).backward()
            opt_e.step()
            opt_c.step()

    dp._spent.append(dp.epsilon)
    return ({k: v.detach().cpu() for k, v in client_model.state_dict().items()},
            {k: v.detach().cpu() for k, v in edge_model.state_dict().items()},
            dp)


# --------------------------------------------------------------------------
# Algorithm 3 -- server round with FedTrust aggregation
# --------------------------------------------------------------------------
def federated_round(global_state, clients, cfg: TrainConfig,
                    trust_cfg: TrustConfig | None = None,
                    round_now: int = 1, device="cpu"):
    """One global round: distribute, train locally, score, aggregate.

    ``clients`` is a sequence of dicts, each carrying at least

        model, loader, capacity, capacity_max, proc_capability,
        round_last, f1, auc

    The trust score is computed from the noised update, from device metadata,
    and from held-out performance -- see the privacy note in fedtrust.py.
    """
    if torch is None:
        raise RuntimeError("PyTorch required")
    trust = FedTrust(trust_cfg or TrustConfig())

    states, mechs = [], []
    for c in clients:
        c["model"].load_state_dict(global_state)
        sd, dp = train_client_rr(c["model"], c["loader"], cfg, device=device)
        states.append(sd)
        mechs.append(dp)

    # behavioural deviation is measured against the mean of the noised updates
    mean = {k: torch.stack([s[k].float() for s in states]).mean(0)
            for k in states[0]}
    scores = []
    for c, sd in zip(clients, states):
        dev = torch.sqrt(sum(((sd[k].float() - mean[k]) ** 2).sum()
                             for k in sd)).item()
        scores.append(trust.score(
            round_now=round_now, round_last=c.get("round_last", round_now - 1),
            f1=c.get("f1", 0.0), auc=c.get("auc", 0.0), deviation=dev,
            capacity=c.get("capacity", 1.0),
            capacity_max=c.get("capacity_max", 1.0),
            proc_capability=c.get("proc_capability", 1.0)))

    return trust.aggregate(states, scores), scores, mechs
