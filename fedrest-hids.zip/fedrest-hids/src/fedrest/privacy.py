"""Localized Renyi Differential Privacy (LRDP).

Canonical implementation of the privacy accounting described in Section 3.2.2
of the article.  The notebooks in ``notebooks/`` each carry their own copy of
this logic and they do not all agree; this module is the single reference
version, and ``docs/KNOWN_ISSUES.md`` records where the notebooks diverge from
it.

Equations, numbered as in the article:

    (2)  M(g) = clip(g, C) + N(0, sigma^2 I),  clip(g, C) = g * min(1, C/||g||_2)
    (4)  sigma = C * sqrt(alpha / (2 * epsilon))
    (5)  eps_dp = eps_total + log(1/delta) / (alpha - 1)

Cross-round composition is additive at a fixed Renyi order:

         eps_total = sum_r eps_r
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Iterable, Sequence

try:                                    # torch is optional for the pure-math API
    import torch
except ImportError:                     # pragma: no cover
    torch = None


# --------------------------------------------------------------------------
# Core accounting
# --------------------------------------------------------------------------
def noise_scale(clip_norm: float, alpha: float, epsilon: float) -> float:
    """Gaussian noise standard deviation for one release -- Eq. (4).

    Derived by equating the Renyi divergence of the Gaussian mechanism,
    D_alpha = alpha * C^2 / (2 * sigma^2), to the per-round budget and solving
    for sigma.  For a single Gaussian release this inversion is exact.

    NOTE the distinction from the classical (eps, delta) Gaussian mechanism,
    sigma = Delta * sqrt(2 * ln(1.25/delta)) / eps, which several notebooks use
    instead.  The two are not interchangeable: the classical form composes in
    (eps, delta) space and incurs the advanced-composition penalty, whereas the
    Renyi form composes additively at fixed alpha and is converted once.
    """
    if alpha <= 1:
        raise ValueError("Renyi order alpha must be > 1")
    if epsilon <= 0:
        raise ValueError("per-round budget epsilon must be > 0")
    if clip_norm <= 0:
        raise ValueError("clipping norm C must be > 0")
    return clip_norm * math.sqrt(alpha / (2.0 * epsilon))


def compose(per_round: Sequence[float]) -> float:
    """Additive composition across rounds at a fixed Renyi order."""
    return float(sum(per_round))


def rdp_to_dp(eps_total: float, alpha: float, delta: float = 1e-5) -> float:
    """Convert a composed (alpha, eps_total)-RDP bound to (eps, delta)-DP.

    Eq. (5); the standard conversion of Mironov (2017).  Apply this ONCE, to
    the composed budget -- converting per round and then summing gives a
    needlessly loose bound.
    """
    if not 0 < delta < 1:
        raise ValueError("delta must lie in (0, 1)")
    return eps_total + math.log(1.0 / delta) / (alpha - 1.0)


def allocate(eps_total: float,
             capability: Sequence[float],
             sensitivity: Sequence[float]) -> list[float]:
    """Heterogeneity-aware per-round budget allocation -- Eq. (3).

    Distributes eps_total across the participating clients in proportion to the
    product of a capability weight and a cluster sensitivity weight.

    Specified in the article as a design element and NOT exercised by the
    reported experiments, which apply the per-round budget uniformly.  Provided
    here so the rule is reproducible.
    """
    if len(capability) != len(sensitivity):
        raise ValueError("capability and sensitivity must be the same length")
    w = [c * s for c, s in zip(capability, sensitivity)]
    total = sum(w)
    if total <= 0:
        raise ValueError("weights must sum to a positive value")
    return [eps_total * wi / total for wi in w]


# --------------------------------------------------------------------------
# Mechanism
# --------------------------------------------------------------------------
@dataclass
class LocalRenyiDP:
    """Per-client Gaussian mechanism under a per-round Renyi budget.

    Parameters
    ----------
    clip_norm   : l2 clipping norm C bounding the sensitivity of one release
    alpha       : Renyi order (> 1)
    epsilon     : per-round Renyi budget
    delta       : failure probability, used only for the final conversion
    """
    clip_norm: float = 1.0
    alpha: float = 5.0
    epsilon: float = 0.5
    delta: float = 1e-5

    def __post_init__(self) -> None:
        self.sigma = noise_scale(self.clip_norm, self.alpha, self.epsilon)
        self._spent: list[float] = []

    # -- mechanism -------------------------------------------------------
    def clip(self, tensor):
        """Scale a tensor so its l2 norm does not exceed ``clip_norm``."""
        if torch is None:
            raise RuntimeError("PyTorch required for tensor operations")
        norm = torch.norm(tensor, p=2)
        factor = min(1.0, self.clip_norm / (norm.item() + 1e-12))
        return tensor * factor

    def perturb(self, tensor, generator=None):
        """Add N(0, sigma^2) noise, elementwise."""
        if torch is None:
            raise RuntimeError("PyTorch required for tensor operations")
        noise = torch.normal(
            mean=0.0, std=self.sigma, size=tensor.shape,
            device=tensor.device, dtype=tensor.dtype, generator=generator,
        )
        return tensor + noise

    def privatize(self, tensor, generator=None):
        """Clip then perturb -- Eq. (2)."""
        out = self.perturb(self.clip(tensor), generator=generator)
        self._spent.append(self.epsilon)
        return out

    # -- accounting ------------------------------------------------------
    def rounds_spent(self) -> int:
        return len(self._spent)

    def epsilon_total(self) -> float:
        return compose(self._spent)

    def epsilon_dp(self) -> float:
        """Composed budget expressed as (eps, delta)-DP."""
        return rdp_to_dp(self.epsilon_total(), self.alpha, self.delta)

    def report(self) -> str:
        return (f"rounds={self.rounds_spent()}  alpha={self.alpha}  "
                f"eps_per_round={self.epsilon}  sigma={self.sigma:.4f}  "
                f"eps_total={self.epsilon_total():.2f}  "
                f"eps_dp={self.epsilon_dp():.2f} at delta={self.delta:g}")


if __name__ == "__main__":
    # Reproduces the headline operating point of Section 6.1 and Table 4.
    m = LocalRenyiDP(clip_norm=1.0, alpha=5.0, epsilon=0.5)
    print(f"sigma = {m.sigma:.3f}          (article reports 2.236)")
    for _ in range(50):
        m._spent.append(m.epsilon)
    print(f"eps_total after 50 rounds = {m.epsilon_total():.1f}   (article: 25.0)")
    print(f"eps_dp at delta=1e-5      = {m.epsilon_dp():.2f}  (article: 27.88)")

    # Appendix C worked example.
    eps = allocate(1.0, capability=[1.5, 1.0, 0.5], sensitivity=[1.5, 1.0, 0.5])
    print("\nAppendix C allocation:", [f"{e:.3f}" for e in eps],
          "(article: 0.643, 0.286, 0.071)")
    print("sigma:", [f"{noise_scale(1.0, 10.0, e):.2f}" for e in eps],
          "(article: 2.79, 4.18, 8.37)")
