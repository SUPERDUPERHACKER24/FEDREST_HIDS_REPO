"""Communication cost of the split pipeline -- Section 6.5 of the article.

    (8)  bytes_SL = 2 * N * A * b * E
    (9)  bytes_FL = 2 * P * b
    (10) split learning is cheaper iff  2 * N * A * E < P

N  samples held by one client
A  values produced by the client-side network for one sample
P  parameter count of the full model
E  local epochs per round
b  bytes per value (4 for float32)

The batch size does not appear: partitioning an epoch into more batches
increases the number of exchanges and decreases the payload of each in exact
proportion.  Appendix F of the supplementary material derives this.
"""
from __future__ import annotations

from dataclasses import dataclass

BYTES_FLOAT32 = 4
BYTES_FLOAT16 = 2
BYTES_INT8 = 1


def bytes_split_learning(n_samples: int, activation_dim: int,
                         local_epochs: int, bytes_per_value: int = BYTES_FLOAT32
                         ) -> int:
    """Per-client, per-round traffic under split learning -- Eq. (8).

    Activations travel up and activation-gradients travel down, once for every
    sample in every local epoch, hence the factor of two and the factor E.
    """
    return 2 * n_samples * activation_dim * bytes_per_value * local_epochs


def bytes_federated(n_parameters: int,
                    bytes_per_value: int = BYTES_FLOAT32) -> int:
    """Per-client, per-round traffic under federated averaging -- Eq. (9).

    The global model travels down and the local update travels up, once per
    round.  Independent of N, E and the batch size, because the data never
    crosses the link.
    """
    return 2 * n_parameters * bytes_per_value


def break_even_parameters(n_samples: int, activation_dim: int,
                          local_epochs: int) -> int:
    """Parameter count P above which split learning becomes cheaper -- Eq. (10)."""
    return 2 * n_samples * activation_dim * local_epochs


@dataclass
class CommsProfile:
    n_samples: int
    activation_dim: int
    n_parameters: int
    local_epochs: int = 3
    bytes_per_value: int = BYTES_FLOAT32

    @property
    def sl(self) -> int:
        return bytes_split_learning(self.n_samples, self.activation_dim,
                                    self.local_epochs, self.bytes_per_value)

    @property
    def fl(self) -> int:
        return bytes_federated(self.n_parameters, self.bytes_per_value)

    @property
    def ratio(self) -> float:
        return self.sl / self.fl

    @property
    def break_even_P(self) -> int:
        return break_even_parameters(self.n_samples, self.activation_dim,
                                     self.local_epochs)

    def summary(self) -> str:
        mb = 1024 * 1024
        cheaper = "split" if self.sl < self.fl else "federated"
        return (f"N={self.n_samples:,}  A={self.activation_dim}  "
                f"P={self.n_parameters:,}  E={self.local_epochs}\n"
                f"  split learning : {self.sl/mb:10.2f} MB / client / round\n"
                f"  federated      : {self.fl/mb:10.2f} MB / client / round\n"
                f"  ratio SL/FL    : {self.ratio:10.1f}x  ({cheaper} is cheaper)\n"
                f"  break-even P   : {self.break_even_P:,} parameters")


if __name__ == "__main__":
    # Table F.2 of the supplementary material, at E = 3.
    print("Break-even parameter count (E = 3)")
    for n in (10_000, 100_000):
        for a in (32, 1312):
            print(f"  N={n:>7,}  A={a:>5}  ->  P > {break_even_parameters(n, a, 3):,.0f}")
    print()
    print(CommsProfile(n_samples=28_000, activation_dim=32,
                       n_parameters=100_000).summary())
