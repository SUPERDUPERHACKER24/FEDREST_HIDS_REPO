"""Poisoning attacks used in the robustness study -- Section 6.3, Table 9.

Two non-colluding strategies are evaluated:

  label flip  a compromised client inverts its training labels
  sign flip   a compromised client negates its parameter update

Both are applied to a fraction of clients drawn uniformly at random.  The
article evaluates fractions of 10%, 20%, 30% and 50%; at 50% the setting is
referred to as the Sybil tolerance limit.

LIMITATION, stated in Section 7: these attackers act independently.  The
framework has NOT been tested against coordinated Byzantine clients that match
behavioural and resource signatures to evade the deviation score, which is the
attack the threat model of Section 3.1 anticipates.
"""
from __future__ import annotations

from typing import Dict, Sequence

try:
    import torch
except ImportError:                     # pragma: no cover
    torch = None


def label_flip(labels, n_classes: int = 2):
    """Invert labels.  Binary: y -> 1 - y.  Multi-class: y -> (n - 1) - y."""
    if torch is None:
        raise RuntimeError("PyTorch required")
    return (n_classes - 1) - labels


def sign_flip(state_dict: Dict, scale: float = 1.0) -> Dict:
    """Negate every parameter tensor -- a gradient-inversion variant."""
    if torch is None:
        raise RuntimeError("PyTorch required")
    return {k: -scale * v for k, v in state_dict.items()}


def select_malicious(n_clients: int, fraction: float, seed: int = 42) -> list[int]:
    """Indices of the compromised clients, drawn without replacement."""
    import random
    if not 0.0 <= fraction <= 1.0:
        raise ValueError("fraction must lie in [0, 1]")
    rng = random.Random(seed)
    k = int(round(fraction * n_clients))
    return sorted(rng.sample(range(n_clients), k))


def apply_attack(state_dict: Dict, attack: str, **kwargs) -> Dict:
    """Dispatch by name.  ``none`` returns the update untouched."""
    if attack in (None, "none", "clean"):
        return state_dict
    if attack == "sign_flip":
        return sign_flip(state_dict, kwargs.get("scale", 1.0))
    if attack == "label_flip":
        # label flipping acts on the data, not the update; the poisoned update
        # is produced by training on flipped labels upstream of this call
        return state_dict
    raise ValueError(f"unknown attack: {attack}")


if __name__ == "__main__":
    for frac in (0.0, 0.1, 0.2, 0.3, 0.5):
        idx = select_malicious(10, frac)
        print(f"fraction={frac:>4}  malicious clients={idx}")
