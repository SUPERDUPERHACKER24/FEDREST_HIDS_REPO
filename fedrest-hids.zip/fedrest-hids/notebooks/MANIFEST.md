# Notebook manifest

The notebooks that produced the reported results, preserved as run. They are
Google Colab exports and have not been refactored — refactoring them would
break the correspondence with the article. The cleaned reference
implementation of the shared mechanisms lives in `src/fedrest/`.

`docs/KNOWN_ISSUES.md` records where these diverge from each other and from
the article.

| Notebook | Dataset | Tier | Features | Size |
|---|---|---|---|---|
| `HIDS_FL_LRDP_RR_IIoT_WUSTL_SCADA_NETWORK2021_with_poisoning.ipynb` | WUSTL-IIoT-2021 | RR | poisoning, ablation | 793 KB |
| `Copy_of_HIDS_FEDSPLITFTIL_RRC_WUSTL.ipynb` | WUSTL-IIoT-2021 | RC | SL + FTL | 107 KB |
| `HIDS_IIoT_RR_ToNIoT_Network_Enhanced.ipynb` | ToN-IoT (network) | RR | — | 408 KB |
| `Copy_of_HIDS_IIoT_RR_ToNIoT_Network.ipynb` | ToN-IoT (network) | RR | — | 27 KB |
| `HIDS_IIoT_RC_ToN_IoT_Network.ipynb` | ToN-IoT (network) | RC | SL + FTL | 33.9 MB |
| `HIDS_Fedrest_RR_ToNIoT_Linux_Process.ipynb` | ToN-IoT (Linux process) | RR | FedTrust | 949 KB |
| `HIDS_FEDREST_LRDP_RR_TONIOTPROCESS_with_poisoning.ipynb` | ToN-IoT (Linux process) | RR | poisoning, FedTrust | 1.17 MB |
| `Copy_of_HIDS_FEDREST_LRDP_RR_TONIOTPROCESS_with_poisoning.ipynb` | ToN-IoT (Linux process) | RR | poisoning, FedTrust | 1.17 MB |
| `HIDS_FEDREST_LRDP_RC_TONIOTPROCESS.ipynb` | ToN-IoT (Linux process) | RC | — | 221 KB |
| `Copy_of_HIDS_FEDREST_LRDP_RC_TONIOTPROCESS.ipynb` | ToN-IoT (Linux process) | RC | — | 255 KB |
| `HIDS_FL_LRDP_RC_IIoT_SCVIC_APT_2021.ipynb` | SCVIC-APT-2021 | RC | SL + FTL | 1.05 MB |
| `HIDS_FEDSPLITFTIL_RRC_SCVIC2021.ipynb` | SCVIC-APT-2021 | RC | SL + FTL | 83 KB |
| `Copy_of_HIDS_FEDSPLITFTIL_RRC_SCVIC2021.ipynb` | SCVIC-APT-2021 | RC | SL + FTL | 79 KB |
| `Enhanced_HIDS_SCVIC_Colab__1_.ipynb` | SCVIC-APT-2021 | RR | FedTrust | 504 KB |
| `Enhanced_HIDS_SCVIC_Colab.ipynb` | SCVIC-APT-2021 | RR | FedTrust | 19 KB |


## Verification notebook

`VERIFY_WUSTL_RR_eps0.5_alpha5.0.ipynb` is not one of the original runs. It is
`HIDS_FL_LRDP_RR_IIoT_WUSTL_SCADA_NETWORK2021_with_poisoning.ipynb` with two
changes, built to confirm the headline result reported in the article:

1. `_compute_noise_scale` now returns Eq. (4), `sigma = C * sqrt(alpha/(2 eps))`
2. the privacy configuration is set to the reported values: `eps = 0.5`,
   `alpha = 5.0`, `C = 1.0`, `noise_scale_factor = 1.0`

Everything else is untouched, so a difference in the outcome can only come from
the privacy mechanism. It must print `sigma=2.2361` when the engine
initialises. See `docs/KNOWN_ISSUES.md` section 2 for why this run is needed.

**Status: run 2026-09-15.** Output in
`results/VERIFY_WUSTL_RR_eps0.5_alpha5.0.txt`. It reproduced the configuration
(σ = 2.2361) and returned 98.30% accuracy, weighted F1 0.9837, balanced
accuracy 0.9889, best validation F1 0.9943 at round 30. The article now reports
these figures, and Figure 2 is generated from this run's per-round log by
`scripts/make_figure2.py`.

## Which notebook produced which result

Best current mapping. **Verify before citing in a rebuttal** — the
correspondence was inferred from notebook content, not from run logs.

| Article item | Notebook |
|---|---|
| Table 3, Table 4 — WUSTL RR sensitivity and horizon | `HIDS_FL_LRDP_RR_IIoT_WUSTL_SCADA_NETWORK2021_with_poisoning` |
| Figure 2 — WUSTL RR convergence | same |
| Table 5, Figures 3–5 — ToN-IoT network RR | `HIDS_IIoT_RR_ToNIoT_Network_Enhanced` |
| Table 6 — ToN-IoT Linux process RR sensitivity | `HIDS_Fedrest_RR_ToNIoT_Linux_Process` |
| Figures 6–11 — SCVIC-APT RR | `Enhanced_HIDS_SCVIC_Colab__1_` |
| Table 7, Figures 12–13 — WUSTL RC, SL + FTL | `Copy_of_HIDS_FEDSPLITFTIL_RRC_WUSTL` |
| Figure 14 — ToN-IoT network RC | `HIDS_IIoT_RC_ToN_IoT_Network` |
| Figures 15–16 — ToN-IoT Linux process RC | `HIDS_FEDREST_LRDP_RC_TONIOTPROCESS` |
| Figures 17–18 — SCVIC-APT RC | `HIDS_FL_LRDP_RC_IIoT_SCVIC_APT_2021` |
| Table 8 — four-component ablation | `HIDS_FL_LRDP_RR_IIoT_WUSTL_SCADA_NETWORK2021_with_poisoning` |
| Table 9 — poisoning / Sybil study | `HIDS_FEDREST_LRDP_RR_TONIOTPROCESS_with_poisoning` |

## Duplicate pairs

Four notebooks exist in two near-identical versions differing by a few thousand
characters. Both are kept rather than guessed between:

- `HIDS_FEDREST_LRDP_RC_TONIOTPROCESS` / `Copy_of_…` (177 KB vs 183 KB of code)
- `HIDS_FEDREST_LRDP_RR_TONIOTPROCESS_with_poisoning` / `Copy_of_…` (67 KB vs 77 KB)
- `HIDS_FEDSPLITFTIL_RRC_SCVIC2021` / `Copy_of_…` (67 KB vs 70 KB)
- `Enhanced_HIDS_SCVIC_Colab` / `…__1_` (13 KB vs 60 KB — the second is far more complete)

Two exist only in `Copy_of_` form, with no original uploaded:
`Copy_of_HIDS_FEDSPLITFTIL_RRC_WUSTL` and `Copy_of_HIDS_IIoT_RR_ToNIoT_Network`.

## Frameworks

Twelve notebooks use PyTorch; three use TensorFlow/Keras
(`Copy_of_HIDS_IIoT_RR_ToNIoT_Network`, `HIDS_Fedrest_RR_ToNIoT_Linux_Process`,
`HIDS_IIoT_RR_ToNIoT_Network_Enhanced`). Both are listed in
`requirements.txt`.
