#!/usr/bin/env python3
"""Audit the privacy configuration declared in each notebook.

Prints what each notebook declares next to what the article reports, so that
any mismatch is visible rather than buried. Needs no dataset and no GPU.

    python scripts/audit_configs.py

CAVEAT: the values are scraped by regular expression. Several notebooks use the
name ``alpha`` for both the Renyi order and a focal-loss parameter, so an
``alpha`` reported here may be the wrong one. Treat the output as a pointer to
where to look, not as ground truth.
"""
import glob
import json
import os
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

# What the article reports, by dataset and device tier.
ARTICLE = {
    "WUSTL RR":   dict(eps=0.5, alpha=5.0, C=1.0, rounds=50, sigma=2.236),
    "ToN-net RR": dict(eps=1.0, alpha=10.0, C=1.0, rounds=50, sigma=None),
    "ToN-proc RR": dict(eps=1.0, alpha=5.0, C=2.0, rounds=50, sigma=3.162),
    "SCVIC RR":   dict(eps=2.0, alpha=5.0, C=1.0, rounds=50, sigma=None),
    "WUSTL RC":   dict(eps=0.5, alpha=5.0, C=1.0, rounds=50, sigma=None),
}


def scrape(src, keys):
    for k in keys:
        m = re.search(r"['\"]?\b" + k + r"\b['\"]?\s*[:=]\s*([0-9.eE+-]+)", src)
        if m:
            try:
                return float(m.group(1))
            except ValueError:
                pass
    return None


def main():
    nbdir = ROOT / "notebooks"
    files = sorted(glob.glob(str(nbdir / "*.ipynb")))
    if not files:
        print("no notebooks found", file=sys.stderr)
        return 1

    print("Declared privacy configuration per notebook\n")
    print(f"{'notebook':<52}{'eps':>7}{'alpha':>8}{'C':>7}{'rounds':>8}")
    print("-" * 82)
    for f in files:
        nb = json.load(open(f, encoding="utf-8"))
        src = "\n".join("\n".join(c.get("source", []))
                        for c in nb["cells"] if c.get("cell_type") == "code")
        eps = scrape(src, ["epsilon", "eps"])
        alpha = scrape(src, ["alpha", "renyi_order"])
        C = scrape(src, ["max_grad_norm", "clip_norm", "clipping_norm"])
        rounds = scrape(src, ["num_rounds", "n_rounds", "global_rounds", "rounds"])
        fmt = lambda v: "-" if v is None else f"{v:g}"
        print(f"{os.path.basename(f)[:50]:<52}"
              f"{fmt(eps):>7}{fmt(alpha):>8}{fmt(C):>7}{fmt(rounds):>8}")

    print("\nReported in the article\n")
    print(f"{'setting':<52}{'eps':>7}{'alpha':>8}{'C':>7}{'rounds':>8}")
    print("-" * 82)
    for k, v in ARTICLE.items():
        print(f"{k:<52}{v['eps']:>7g}{v['alpha']:>8g}{v['C']:>7g}{v['rounds']:>8d}")

    print("\nAny notebook whose eps/alpha differs from the row it is cited for")
    print("needs to be reconciled before the configuration can be said to")
    print("match. See docs/KNOWN_ISSUES.md section 2.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
