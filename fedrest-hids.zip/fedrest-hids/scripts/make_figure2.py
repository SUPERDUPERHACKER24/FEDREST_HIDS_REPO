#!/usr/bin/env python3
"""Regenerate Figure 2 from the per-round training log of the verification run.

The previous version was assembled from screenshots whose axes spanned 0-1.0
while the data occupied 0.93-1.0, so four fifths of the figure was empty. That
forced the whole image to 8.09 in tall and its tick labels to 7.0 pt, exactly
on Elsevier's legibility floor.

Here the figure is drawn at its final printed size -- figsize is 6.845 in, which
is the cas-dc text width -- so no scaling happens in LaTeX and the 9 pt font is
9 pt on the page. The y-axis is cropped to the range the data actually occupies,
which makes the round-to-round variation visible for the first time.

Source: verification run, WUSTL-IIoT-2021, RR devices, eps = 0.5, alpha = 5.0,
C = 1.0, delta = 1e-5, 50 rounds, seed 42.
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# --- per-round log --------------------------------------------------------
rounds = list(range(1, 51))
train = [0.943, 0.981, 0.974, 0.984, 0.983, 0.978, 0.985, 0.980, 0.978, 0.974,
         0.976, 0.975, 0.975, 0.982, 0.976, 0.978, 0.981, 0.978, 0.976, 0.976,
         0.981, 0.981, 0.980, 0.989, 0.980, 0.976, 0.976, 0.979, 0.977, 0.994,
         0.978, 0.982, 0.984, 0.982, 0.976, 0.973, 0.979, 0.984, 0.978, 0.975,
         0.987, 0.981, 0.984, 0.986, 0.980, 0.983, 0.988, 0.987, 0.980, 0.983]
val   = [0.944, 0.981, 0.977, 0.983, 0.982, 0.978, 0.982, 0.978, 0.978, 0.980,
         0.981, 0.977, 0.977, 0.982, 0.981, 0.981, 0.979, 0.976, 0.976, 0.980,
         0.983, 0.979, 0.980, 0.987, 0.980, 0.977, 0.977, 0.976, 0.979, 0.994,
         0.978, 0.982, 0.983, 0.982, 0.976, 0.975, 0.978, 0.984, 0.982, 0.976,
         0.986, 0.981, 0.987, 0.982, 0.981, 0.985, 0.989, 0.987, 0.978, 0.984]
f1    = [0.932, 0.981, 0.978, 0.983, 0.983, 0.979, 0.983, 0.979, 0.979, 0.981,
         0.982, 0.978, 0.979, 0.983, 0.982, 0.982, 0.980, 0.978, 0.978, 0.981,
         0.983, 0.980, 0.981, 0.986, 0.981, 0.978, 0.978, 0.977, 0.980, 0.994,
         0.979, 0.983, 0.984, 0.983, 0.977, 0.977, 0.979, 0.985, 0.982, 0.977,
         0.986, 0.982, 0.987, 0.983, 0.982, 0.986, 0.989, 0.987, 0.979, 0.984]

BEST_ROUND, BEST_F1 = 30, 0.9943          # as reported by the run

assert len(train) == len(val) == len(f1) == 50

# --- style ----------------------------------------------------------------
TEXTWIDTH_IN = 493.0 / 72                  # cas-dc \textwidth
plt.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["DejaVu Sans"],
    "font.size": 9,
    "axes.titlesize": 9,
    "axes.labelsize": 9,
    "xtick.labelsize": 8,
    "ytick.labelsize": 8,
    "legend.fontsize": 7.5,
    "axes.linewidth": 0.6,
    "grid.linewidth": 0.4,
    "lines.linewidth": 1.0,
    "lines.markersize": 2.6,
    "savefig.bbox": "tight",
    "savefig.pad_inches": 0.02,
    "pdf.fonttype": 42,                    # embed TrueType, never Type 3
})

BLUE, PLUM, ORANGE, RED = "#2E6F9E", "#8E3B6B", "#D98324", "#C2312B"

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(TEXTWIDTH_IN, 2.35))

# --- (a) accuracy ---------------------------------------------------------
ax1.plot(rounds, train, "-o", color=BLUE, label="Training accuracy",
         markerfacecolor="white", markeredgewidth=0.7)
ax1.plot(rounds, val, "-s", color=PLUM, label="Validation accuracy",
         markerfacecolor="white", markeredgewidth=0.7)
ax1.axvline(BEST_ROUND, color=RED, ls="--", lw=0.9, alpha=0.85,
            label=f"Best model (round {BEST_ROUND})")
ax1.set_xlabel("Federated round")
ax1.set_ylabel("Accuracy")
ax1.set_title("(a) Training and validation accuracy", pad=6)
ax1.set_ylim(0.935, 1.0)
ax1.set_xlim(0, 51)
ax1.legend(loc="lower right", frameon=True, framealpha=0.9, borderpad=0.35,
           handlelength=1.6, borderaxespad=0.3)

# --- (b) F1 ---------------------------------------------------------------
ax2.plot(rounds, f1, "-D", color=ORANGE, label="Validation F1",
         markerfacecolor="white", markeredgewidth=0.7)
ax2.plot([BEST_ROUND], [f1[BEST_ROUND - 1]], marker="*", markersize=9,
         color=RED, linestyle="none",
         label=f"Best F1 = {BEST_F1:.4f} (round {BEST_ROUND})")
ax2.set_xlabel("Federated round")
ax2.set_ylabel("F1-score")
ax2.set_title("(b) Validation F1-score", pad=6)
ax2.set_ylim(0.925, 1.0)
ax2.set_xlim(0, 51)
ax2.legend(loc="lower right", frameon=True, framealpha=0.9, borderpad=0.35,
           handlelength=1.6, borderaxespad=0.3)

for ax in (ax1, ax2):
    ax.grid(True, ls=":", alpha=0.45)
    ax.set_axisbelow(True)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)

fig.tight_layout(pad=0.4, w_pad=1.4)
fig.savefig("Figure_2_new.pdf")
print("written Figure_2_new.pdf")
