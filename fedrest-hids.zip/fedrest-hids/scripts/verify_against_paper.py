#!/usr/bin/env python3
"""Verify the reference implementation against the values printed in the article.

Runs in a second, needs no dataset and no GPU. Every check compares a number
computed by `src/fedrest/` against the corresponding number in the text.

    python scripts/verify_against_paper.py
"""
import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from fedrest.privacy import noise_scale, compose, rdp_to_dp, allocate   # noqa: E402
from fedrest.comms import break_even_parameters                          # noqa: E402
from fedrest.fedtrust import softmax                                     # noqa: E402

CHECKS = []


def check(name, got, want, tol=5e-3, where=""):
    ok = abs(got - want) <= tol * max(1.0, abs(want))
    CHECKS.append(ok)
    flag = "PASS" if ok else "FAIL"
    print(f"  [{flag}] {name:<52} got {got:>12,.4f}  article {want:>12,.4f}   {where}")


print("Privacy accounting -- Section 3.2.2, Section 5.2, Table 4")
check("sigma, WUSTL headline (C=1, a=5, eps=0.5)",
      noise_scale(1.0, 5.0, 0.5), 2.236, where="Sec. 5.2")
check("sigma, ToN-IoT Linux (C=2, a=5, eps=1.0)",
      noise_scale(2.0, 5.0, 1.0), 3.162, where="Sec. 5.2")
check("eps_total, 50 rounds at eps=0.5",
      compose([0.5] * 50), 25.0, where="Table 4")
check("eps_DP at delta=1e-5, alpha=5",
      rdp_to_dp(25.0, 5.0, 1e-5), 27.88, where="Table 4")
check("eps_total, 5 rounds", compose([0.5] * 5), 2.5, where="Table 4")
check("eps_DP, 5 rounds", rdp_to_dp(2.5, 5.0, 1e-5), 5.38, where="Table 4")
check("eps_total, 10 rounds", compose([0.5] * 10), 5.0, where="Table 4")
check("eps_DP, 10 rounds", rdp_to_dp(5.0, 5.0, 1e-5), 7.88, where="Table 4")
check("conversion constant, alpha=5",
      math.log(1e5) / 4, 2.88, where="Appendix D")
check("conversion constant, alpha=10",
      math.log(1e5) / 9, 1.28, where="Appendix D")

print("\nHeterogeneity-aware allocation -- Eq. (3), Appendix C")
eps = allocate(1.0, capability=[1.5, 1.0, 0.5], sensitivity=[1.5, 1.0, 0.5])
check("epsilon_1", eps[0], 0.643, where="Appendix C")
check("epsilon_2", eps[1], 0.286, where="Appendix C")
check("epsilon_3", eps[2], 0.071, tol=1e-2, where="Appendix C")
check("sum of allocations equals eps_tot", sum(eps), 1.0, where="Eq. (3)")
for i, want in enumerate((2.79, 4.18, 8.37), start=1):
    check(f"sigma_{i} at alpha=10", noise_scale(1.0, 10.0, eps[i - 1]), want,
          where="Appendix C")
check("sigma_3 / sigma_1 ratio",
      noise_scale(1.0, 10.0, eps[2]) / noise_scale(1.0, 10.0, eps[0]), 3.0,
      tol=2e-2, where='Appendix C "roughly three times"')

print("\nCommunication cost -- Section 6.5, Table F.2")
check("break-even P, N=1e4 A=32 E=3",
      break_even_parameters(10_000, 32, 3), 1.92e6, where="Table F.2")
check("break-even P, N=1e4 A=1312 E=3",
      break_even_parameters(10_000, 1312, 3), 7.87e7, where="Table F.2")
check("break-even P, N=1e5 A=32 E=3",
      break_even_parameters(100_000, 32, 3), 1.92e7, where="Table F.2")
check("break-even P, N=1e5 A=1312 E=3",
      break_even_parameters(100_000, 1312, 3), 7.87e8, where="Table F.2")

print("\nFedTrust -- Section 3.2.3")
w = softmax([1.0, 1.0, 1.0])
check("uniform scores give uniform weights", w[0], 1 / 3, where="Eq. softmax")
check("softmax weights sum to 1", sum(w), 1.0)

n_pass, n_tot = sum(CHECKS), len(CHECKS)
print(f"\n{n_pass}/{n_tot} checks passed")
sys.exit(0 if n_pass == n_tot else 1)
