# Data paths to change

The notebooks were written for Google Colab and read from
`/content/sample_data/`. Every path below must be repointed at your own
copy of the dataset before the notebook will run.

| Notebook | Path referenced |
|---|---|
| `Copy_of_HIDS_FEDREST_LRDP_RC_TONIOTPROCESS.ipynb` | `/content/sample_data/Train_Test_Linux_process.csv` |
| `Copy_of_HIDS_FEDREST_LRDP_RR_TONIOTPROCESS_with_poisoning.ipynb` | `/content/sample_data/Train_Test_Linux_process.csv` |
| `Copy_of_HIDS_FEDSPLITFTIL_RRC_SCVIC2021.ipynb` | `/content/sample_data/SCVIC-APT-2021-Testing.csv` |
| `Copy_of_HIDS_FEDSPLITFTIL_RRC_SCVIC2021.ipynb` | `/content/sample_data/SCVIC-APT-2021-Training.csv` |
| `Copy_of_HIDS_IIoT_RR_ToNIoT_Network.ipynb` | `/content/sample_data/SCVIC-APT-2021-Training.csv` |
| `HIDS_FEDREST_LRDP_RC_TONIOTPROCESS.ipynb` | `/content/sample_data/Train_Test_Linux_process.csv` |
| `HIDS_FEDREST_LRDP_RR_TONIOTPROCESS_with_poisoning.ipynb` | `/content/Train_Test_Linux_process.csv` |
| `HIDS_FEDSPLITFTIL_RRC_SCVIC2021.ipynb` | `/content/drive/MyDrive/{save_dir}` |
| `HIDS_Fedrest_RR_ToNIoT_Linux_Process.ipynb` | `/content/graph_10_roc_curve.png` |
| `HIDS_Fedrest_RR_ToNIoT_Linux_Process.ipynb` | `/content/graph_11_precision_recall_curve.png` |
| `HIDS_Fedrest_RR_ToNIoT_Linux_Process.ipynb` | `/content/graph_1_test_accuracy.png` |
| `HIDS_Fedrest_RR_ToNIoT_Linux_Process.ipynb` | `/content/graph_2_test_loss.png` |
| `HIDS_Fedrest_RR_ToNIoT_Linux_Process.ipynb` | `/content/graph_3_roc_auc.png` |
| `HIDS_Fedrest_RR_ToNIoT_Linux_Process.ipynb` | `/content/graph_4_precision_recall_f1.png` |
| `HIDS_Fedrest_RR_ToNIoT_Linux_Process.ipynb` | `/content/graph_5_train_vs_test_accuracy.png` |
| `HIDS_Fedrest_RR_ToNIoT_Linux_Process.ipynb` | `/content/graph_6_trust_scores.png` |
| `HIDS_Fedrest_RR_ToNIoT_Linux_Process.ipynb` | `/content/graph_7_privacy_budget.png` |
| `HIDS_Fedrest_RR_ToNIoT_Linux_Process.ipynb` | `/content/graph_8_global_loss.png` |
| `HIDS_Fedrest_RR_ToNIoT_Linux_Process.ipynb` | `/content/graph_9_confusion_matrix.png` |
| `HIDS_Fedrest_RR_ToNIoT_Linux_Process.ipynb` | `/content/hids_fedrest_final_report_{timestamp}.json` |
| `HIDS_Fedrest_RR_ToNIoT_Linux_Process.ipynb` | `/content/sample_data/ToN_IoT_Train_Test_Linux_process.csv` |
| `HIDS_IIoT_RC_ToN_IoT_Network.ipynb` | `/content/sample_data/train_test_network.csv` |
| `HIDS_IIoT_RR_ToNIoT_Network_Enhanced.ipynb` | `/content/sample_data/train_test_network.csv` |

## Recommended change

Replace the hard-coded string with a variable at the top of the notebook:

```python
import os
DATA_DIR = os.environ.get("FEDREST_DATA", "./data")
CSV = os.path.join(DATA_DIR, "Train_Test_Linux_process.csv")
```

Then set `FEDREST_DATA` once for your environment rather than editing
each notebook.
